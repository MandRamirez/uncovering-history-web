"use client";

import { useEffect, useState } from "react";

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8080";

// tipo que vem da API na listagem
type TipoBruto =
  | string
  | {
      id: string;
      name: string;
      icon?: string;
      color?: string;
    };

type InterestPoint = {
  objectId: string;
  name: string;
  lat: number;
  lon: number;
  type: TipoBruto;
  address?: string | null;
  neighborhood?: string | null;
  description?: string | null;
};

function getTypeName(t: TipoBruto): string {
  return typeof t === "string" ? t : t.name ?? "";
}

export default function PontosPage() {
  const [pontos, setPontos] = useState<InterestPoint[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);
        setError(null);

        const res = await fetch(`${API_URL}/api/interest-points`);
        if (!res.ok) {
          throw new Error(`HTTP ${res.status}`);
        }

        const data: InterestPoint[] = await res.json();
        setPontos(data);
      } catch (err: any) {
        console.error(err);
        setError(err.message ?? "Erro ao buscar pontos");
      } finally {
        setLoading(false);
      }
    };

    load();
  }, []);

  if (loading) return <p>Carregando...</p>;
  if (error) return <p style={{ color: "red" }}>Erro: {error}</p>;

  return (
    <main
      style={{
        background: "#000",
        color: "#fff",
        minHeight: "100vh",
        padding: "2rem",
      }}
    >
      <h1>Lista de Pontos de Interesse</h1>
      <p>Total: {pontos.length}</p>

      {pontos.map((p) => {
        const tipo = getTypeName(p.type);

        return (
          <section key={p.objectId} style={{ marginBottom: "2rem" }}>
            {/* LINK para /pontos/[id] */}
            <h2>
              <a
                href={`/pontos/${p.objectId}`}
                style={{ color: "#4da3ff", textDecoration: "underline" }}
              >
                {p.name}
              </a>
              {tipo && <> ({tipo})</>}
            </h2>

            {p.neighborhood && (
              <p>
                <strong>Bairro:</strong> {p.neighborhood}
              </p>
            )}
            {p.address && (
              <p>
                <strong>Endereço:</strong> {p.address}
              </p>
            )}

            <p>
              <strong>Lat/Lon:</strong> {p.lat}, {p.lon}
            </p>

            {p.description && <p>{p.description}</p>}
          </section>
        );
      })}
    </main>
  );
}
