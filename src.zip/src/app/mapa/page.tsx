// src/app/mapa/page.tsx
"use client";

import dynamic from "next/dynamic";
import { useEffect, useState } from "react";
import "leaflet/dist/leaflet.css";

// Carrega react-leaflet só no client
const MapContainer = dynamic(
  () => import("react-leaflet").then((m) => m.MapContainer),
  { ssr: false }
);
const TileLayer = dynamic(
  () => import("react-leaflet").then((m) => m.TileLayer),
  { ssr: false }
);
const Marker = dynamic(
  () => import("react-leaflet").then((m) => m.Marker),
  { ssr: false }
);
const Popup = dynamic(
  () => import("react-leaflet").then((m) => m.Popup),
  { ssr: false }
);

type Tipo = {
  id: string;
  name: string;
  icon: string;
  color: string;
};

type InterestPoint = {
  objectId: string;
  name: string;
  description?: string;
  lat: number;
  lon: number;
  type?: Tipo;
};

const API_BASE = process.env.NEXT_PUBLIC_API_URL;

export default function MapaPage() {
  const [pontos, setPontos] = useState<InterestPoint[]>([]);
  const [erro, setErro] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function carregar() {
      if (!API_BASE) {
        setErro("NEXT_PUBLIC_API_URL não está configurada.");
        setLoading(false);
        return;
      }

      try {
        const resp = await fetch(`${API_BASE}/api/interest-points`);
        if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
        const data: InterestPoint[] = await resp.json();
        setPontos(data);
      } catch (e: any) {
        setErro(e.message || "Erro ao carregar pontos");
      } finally {
        setLoading(false);
      }
    }

    carregar();
  }, []);

  if (loading) {
    return <main style={{ padding: 24, background: "black", color: "white" }}>Carregando mapa...</main>;
  }

  if (erro) {
    return (
      <main style={{ padding: 24, background: "black", color: "red" }}>
        Erro: {erro}
      </main>
    );
  }

  // Centro aproximado Santana do Livramento
  const center: [number, number] = [-30.885, -55.51];

  return (
    <main style={{ height: "100vh", width: "100vw" }}>
      <MapContainer center={center} zoom={15} style={{ height: "100%", width: "100%" }}>
        <TileLayer
          attribution='&copy; OpenStreetMap contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        {pontos.map((p) => (
          <Marker key={p.objectId} position={[p.lat, p.lon]}>
            <Popup>
              <strong>{p.name}</strong>
              {p.type && <div>Tipo: {p.type.name}</div>}
              {p.description && <div style={{ marginTop: 4 }}>{p.description}</div>}
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </main>
  );
}
